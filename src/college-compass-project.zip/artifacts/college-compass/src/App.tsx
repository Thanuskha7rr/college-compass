import { AppLayout } from "@/components/layout/app-layout";
import { CompareProvider } from "@/context/compare-context";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Home from "@/pages/home";
import Search from "@/pages/search";
import Detail from "@/pages/detail";
import Compare from "@/pages/compare";
import Favorites from "@/pages/favorites";
import Quiz from "@/pages/quiz";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/colleges" component={Search} />
      <Route path="/colleges/:id" component={Detail} />
      <Route path="/compare" component={Compare} />
      <Route path="/favorites" component={Favorites} />
      <Route path="/quiz" component={Quiz} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CompareProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppLayout>
              <Router />
            </AppLayout>
          </WouterRouter>
          <Toaster />
        </CompareProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
