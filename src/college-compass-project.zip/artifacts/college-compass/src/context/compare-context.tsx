import { createContext, useContext, useState, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";

interface CompareContextType {
  compareIds: number[];
  addCollege: (id: number) => void;
  removeCollege: (id: number) => void;
  clearCompare: () => void;
}

const CompareContext = createContext<CompareContextType | undefined>(undefined);

export function CompareProvider({ children }: { children: ReactNode }) {
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const { toast } = useToast();

  const addCollege = (id: number) => {
    if (compareIds.includes(id)) return;
    if (compareIds.length >= 3) {
      toast({
        title: "Limit reached",
        description: "You can only compare up to 3 colleges at a time.",
        variant: "destructive",
      });
      return;
    }
    setCompareIds([...compareIds, id]);
    toast({
      title: "Added to compare",
      description: "College added to your comparison list.",
    });
  };

  const removeCollege = (id: number) => {
    setCompareIds(compareIds.filter((compareId) => compareId !== id));
  };

  const clearCompare = () => {
    setCompareIds([]);
  };

  return (
    <CompareContext.Provider value={{ compareIds, addCollege, removeCollege, clearCompare }}>
      {children}
    </CompareContext.Provider>
  );
}

export function useCompare() {
  const context = useContext(CompareContext);
  if (context === undefined) {
    throw new Error("useCompare must be used within a CompareProvider");
  }
  return context;
}
