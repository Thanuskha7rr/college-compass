import { useCompare } from "@/context/compare-context";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { BarChart2, X } from "lucide-react";

export function CompareBar() {
  const { compareIds, clearCompare } = useCompare();

  if (compareIds.length < 2) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-bottom-10 fade-in duration-300">
      <div className="bg-white/90 backdrop-blur-lg rounded-2xl px-6 py-4 border border-blue-100 flex items-center gap-6 shadow-2xl transition-all duration-300">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 text-primary w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
            {compareIds.length}
          </div>
          <span className="font-semibold text-foreground text-sm">
            Colleges Selected
          </span>
        </div>
        
        <div className="flex items-center gap-3 ml-4">
          <Link href="/compare">
            <Button className="btn-gradient font-bold shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 rounded-lg h-9 px-4">
              <BarChart2 className="w-4 h-4 mr-2" />
              Compare Now
            </Button>
          </Link>
          <Button variant="ghost" size="icon" onClick={clearCompare} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full h-9 w-9">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
