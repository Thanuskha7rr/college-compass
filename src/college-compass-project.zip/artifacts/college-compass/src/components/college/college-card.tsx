import { Link } from "wouter";
import { Heart, MapPin, Users, Award, Percent } from "lucide-react";
import { College } from "@workspace/api-client-react/src/generated/api.schemas";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAddFavorite, useRemoveFavorite, useGetFavorites, getGetFavoritesQueryKey } from "@workspace/api-client-react";
import { useCompare } from "@/context/compare-context";
import { useQueryClient } from "@tanstack/react-query";

interface CollegeCardProps {
  college: College;
}

export function CollegeCard({ college }: CollegeCardProps) {
  const { data: favorites } = useGetFavorites();
  const queryClient = useQueryClient();
  
  const isFavorite = favorites?.some(f => f.collegeId === college.id);
  const addFavorite = useAddFavorite();
  const removeFavorite = useRemoveFavorite();
  const { addCollege, removeCollege, compareIds } = useCompare();
  
  const isComparing = compareIds.includes(college.id);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const action = isFavorite ? removeFavorite : addFavorite;
    action.mutate({ collegeId: college.id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetFavoritesQueryKey() });
      }
    });
  };

  const toggleCompare = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isComparing) {
      removeCollege(college.id);
    } else {
      addCollege(college.id);
    }
  };

  return (
    <Link href={`/colleges/${college.id}`} className="group block h-full">
      <div className="h-full flex flex-col bg-white rounded-xl border border-gray-100 shadow-[0_2px_8px_rgba(0,0,0,0.06)] hover:shadow-[0_8px_24px_rgba(37,99,235,0.12)] hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
        {/* Accent Top Bar */}
        <div className="h-1.5 w-full" style={{ background: college.color ? `linear-gradient(90deg, ${college.color}, ${college.color}dd)` : 'linear-gradient(90deg, hsl(224 71% 51%), hsl(262 83% 58%))' }} />
        
        <div className="relative aspect-[16/9] overflow-hidden bg-gray-50 border-b border-gray-50">
          {college.imageUrl ? (
            <img src={college.imageUrl} alt={college.name} className="object-cover w-full h-full opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" />
          ) : (
            <div className="w-full h-full flex items-center justify-center font-semibold text-4xl text-gray-200">
              {college.name.substring(0,2).toUpperCase()}
            </div>
          )}
          <div className="absolute top-3 right-3 flex gap-2">
            <Button 
              variant="outline" 
              size="icon"
              onClick={toggleFavorite}
              className={`rounded-full h-8 w-8 shadow-sm backdrop-blur-md border-white/20 transition-all duration-300 ${isFavorite ? 'bg-white/90 text-red-500 border-red-100' : 'bg-white/70 text-gray-700 hover:bg-white/90 hover:text-red-500'}`}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
            </Button>
          </div>
        </div>

        <div className="p-5 flex-1 flex flex-col">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold text-xl leading-tight text-foreground line-clamp-2 group-hover:text-primary transition-colors">{college.name}</h3>
          </div>
          
          <div className="flex items-center text-sm font-medium text-muted-foreground mb-4">
            <MapPin size={14} className="mr-1.5 text-primary/70" />
            {college.location}, {college.state}
          </div>
          
          <div className="grid grid-cols-2 gap-y-3 gap-x-2 mt-auto text-sm text-foreground/80">
            <div className="flex items-center gap-1.5 font-medium">
              <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                <Percent size={12} />
              </div>
              {college.acceptanceRate}% Accept
            </div>
            <div className="flex items-center gap-1.5 font-medium">
              <div className="w-6 h-6 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                <Users size={12} />
              </div>
              {(college.enrollment / 1000).toFixed(1)}k
            </div>
            <div className="flex items-center gap-1.5 font-medium">
              <div className="w-6 h-6 rounded-full bg-sky-50 flex items-center justify-center text-sky-600">
                <Award size={12} />
              </div>
              Rank #{college.ranking}
            </div>
            <div className="flex items-center gap-1.5 font-medium">
              <span className="text-xs font-semibold px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                {college.type === 'private' ? 'Private' : college.type === 'public' ? 'Public' : 'Liberal Arts'}
              </span>
            </div>
          </div>
          
          <div className="mt-5 pt-4 border-t border-gray-100 flex gap-2">
            <Button 
              onClick={toggleCompare}
              variant={isComparing ? "default" : "outline"} 
              className={`w-full font-semibold rounded-lg transition-all duration-300 ${isComparing ? 'bg-primary/10 text-primary hover:bg-primary/20 border-primary/20' : 'text-muted-foreground hover:text-primary hover:border-primary/30'}`}
            >
              {isComparing ? 'Added to Compare' : '+ Compare'}
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
