import { ReactNode } from "react";
import { Navbar } from "./navbar";
import { CompareBar } from "../college/compare-bar";

export function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/20 selection:text-primary">
      <Navbar />
      <main className="flex-1 flex flex-col relative">
        {children}
      </main>
      <CompareBar />
      <footer className="bg-gradient-to-br from-gray-900 to-blue-950 text-white py-12 border-t border-white/10">
        <div className="container mx-auto px-4 text-center space-y-6">
          <div className="inline-flex w-12 h-12 bg-white/10 rounded-xl text-white p-2.5 backdrop-blur-md shadow-lg border border-white/10">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><polygon points="16.39 21 15.71 16.82 20.3 14.7 17.6 10.45 20.3 6.2 15.71 4.08 16.39 0 11.89 2.11 7.39 0 8.08 4.08 3.49 6.2 6.1 10.45 3.49 14.7 8.08 16.82 7.39 21 11.89 18.89 16.39 21"/></svg>
          </div>
          <p className="font-semibold text-sm tracking-wide text-white/60">Built for ambition.</p>
        </div>
      </footer>
    </div>
  );
}
