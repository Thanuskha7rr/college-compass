import { Link } from "wouter";
import { Compass, Heart, BarChart2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navbar() {
  return (
    <nav className="border-b border-white/20 bg-white/80 backdrop-blur-md sticky top-0 z-50 transition-all duration-300">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary text-white flex items-center justify-center font-bold font-mono group-hover:-rotate-12 transition-transform duration-300 shadow-md">
            <Compass size={20} />
          </div>
          <span className="font-bold text-xl tracking-tighter bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">College Compass</span>
        </Link>
        
        <div className="flex items-center gap-6">
          <Link href="/colleges" className="text-sm font-semibold tracking-wide text-foreground/80 hover:text-primary hover:underline decoration-primary decoration-2 underline-offset-4 hidden sm:block transition-all duration-300">
            Browse
          </Link>
          <Link href="/compare" className="text-sm font-semibold tracking-wide text-foreground/80 hover:text-primary hover:underline decoration-primary decoration-2 underline-offset-4 hidden sm:flex items-center gap-1 transition-all duration-300">
            <BarChart2 size={16} /> Compare
          </Link>
          <Link href="/quiz" className="hidden sm:block">
            <Button className="btn-gradient border-0 font-bold tracking-wide shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 rounded-lg">
              <Sparkles className="mr-2 h-4 w-4" /> Find My Match
            </Button>
          </Link>
          <Link href="/favorites">
            <Button variant="outline" className="border-border text-foreground font-semibold tracking-wide shadow-sm hover:shadow-md hover:border-primary/30 hover:text-primary hover:-translate-y-0.5 transition-all duration-300 rounded-lg bg-white/50 backdrop-blur-sm">
              <Heart className="mr-2 h-4 w-4 text-secondary" /> Favorites
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
}
