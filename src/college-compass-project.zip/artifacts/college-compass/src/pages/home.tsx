import { useState } from "react";
import { useLocation } from "wouter";
import { Search as SearchIcon, ArrowRight, BookOpen, Map, Target, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CollegeCard } from "@/components/college/college-card";
import { useGetCollegeStats, useGetFeaturedColleges } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");

  const { data: stats, isLoading: statsLoading } = useGetCollegeStats();
  const { data: featuredColleges, isLoading: featuredLoading } = useGetFeaturedColleges();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      setLocation(`/colleges?search=${encodeURIComponent(search.trim())}`);
    } else {
      setLocation("/colleges");
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#0f172a] via-[#1e3a8a] to-[#4c1d95] text-white pt-32 pb-40 px-4 relative overflow-hidden">
        {/* Subtle grid background & grain */}
        <div className="absolute inset-0 opacity-[0.03] mix-blend-overlay" style={{backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E\")"}}></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff1a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff1a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/30 rounded-full blur-[120px] opacity-50 pointer-events-none"></div>

        <div className="container mx-auto max-w-5xl relative z-10 text-center">
          <div className="inline-block bg-white/10 border border-white/20 px-4 py-1.5 mb-8 text-sm font-semibold tracking-wide uppercase text-white rounded-full backdrop-blur-md shadow-lg">
            The New Standard in College Discovery
          </div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter leading-[1.1] mb-8">
            Find the college that <br className="hidden md:block" />
            <span className="bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">matches your ambition.</span>
          </h1>
          
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto flex flex-col sm:flex-row gap-4 mt-12 relative z-20">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-6 w-6 text-gray-400" />
              <Input 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by college name or location..." 
                className="h-16 pl-14 text-lg bg-white/95 backdrop-blur-sm text-foreground border-0 focus-visible:ring-2 focus-visible:ring-primary rounded-xl shadow-lg transition-all duration-300"
              />
            </div>
            <Button type="submit" size="lg" className="h-16 px-10 text-lg font-bold tracking-wide btn-gradient rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border-0">
              Explore
            </Button>
          </form>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-b from-blue-50 to-purple-50 relative -mt-10 rounded-t-[3rem] shadow-sm z-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {statsLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex flex-col items-center bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                  <Skeleton className="h-10 w-24 mb-3 bg-blue-50 rounded-lg" />
                  <Skeleton className="h-4 w-32 bg-blue-50 rounded-md" />
                </div>
              ))
            ) : stats ? (
              <>
                <div className="flex flex-col items-center text-center bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
                    <BookOpen size={24} />
                  </div>
                  <div className="text-4xl md:text-5xl font-bold tracking-tighter mb-2 text-foreground">{stats.totalColleges.toLocaleString()}</div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    Colleges
                  </div>
                </div>
                <div className="flex flex-col items-center text-center bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mb-4">
                    <Map size={24} />
                  </div>
                  <div className="text-4xl md:text-5xl font-bold tracking-tighter mb-2 text-foreground">{stats.states}</div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    States
                  </div>
                </div>
                <div className="flex flex-col items-center text-center bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-full bg-sky-100 text-sky-600 flex items-center justify-center mb-4">
                    <Target size={24} />
                  </div>
                  <div className="text-4xl md:text-5xl font-bold tracking-tighter mb-2 text-foreground">{stats.avgAcceptanceRate}%</div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    Avg Acceptance
                  </div>
                </div>
                <div className="flex flex-col items-center text-center bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4">
                    <Users size={24} />
                  </div>
                  <div className="text-4xl md:text-5xl font-bold tracking-tighter mb-2 text-foreground">{(stats.totalStudents / 1000000).toFixed(1)}M+</div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                    Students
                  </div>
                </div>
              </>
            ) : null}
          </div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div className="border-l-4 border-primary pl-6">
              <h2 className="text-4xl font-bold tracking-tighter mb-3 text-foreground">Featured Institutions</h2>
              <p className="text-xl text-muted-foreground max-w-2xl">Discover top-ranked colleges setting the standard for higher education.</p>
            </div>
            <Button variant="outline" className="hidden sm:flex font-semibold tracking-wide shadow-sm hover:shadow-md transition-all h-12 px-6 rounded-lg text-primary border-primary/20 hover:bg-primary/5" onClick={() => setLocation("/colleges")}>
              View All <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="border border-gray-100 p-4 rounded-xl bg-white shadow-sm">
                  <Skeleton className="h-48 w-full bg-blue-50 mb-4 rounded-lg" />
                  <Skeleton className="h-6 w-3/4 bg-blue-50 mb-2 rounded-md" />
                  <Skeleton className="h-4 w-1/2 bg-blue-50 rounded-md" />
                </div>
              ))
            ) : featuredColleges ? (
              featuredColleges.map((college) => (
                <CollegeCard key={college.id} college={college} />
              ))
            ) : (
              <div className="col-span-full py-12 text-center text-muted-foreground bg-gray-50 rounded-xl border border-dashed border-gray-200">No featured colleges found.</div>
            )}
          </div>
          
          <div className="mt-12 sm:hidden">
            <Button variant="outline" className="w-full font-semibold tracking-wide shadow-sm hover:shadow-md transition-all h-12 rounded-lg text-primary border-primary/20 hover:bg-primary/5" onClick={() => setLocation("/colleges")}>
              View All <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-b from-white to-blue-50 border-t border-gray-100">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tighter mb-6 text-foreground">Ready to find your match?</h2>
          <p className="text-xl text-muted-foreground mb-10">Stop guessing. Start comparing programs, costs, and outcomes to make the best decision for your future.</p>
          <Button size="lg" className="h-16 px-12 text-lg font-bold tracking-wide btn-gradient shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 rounded-xl" onClick={() => setLocation("/colleges")}>
            Start Browsing
          </Button>
        </div>
      </section>
    </div>
  );
}
