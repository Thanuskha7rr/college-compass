import { Link } from "wouter";
import { useCompare } from "@/context/compare-context";
import { useCompareColleges } from "@workspace/api-client-react";
import { useEffect, useState } from "react";
import { College } from "@workspace/api-client-react/src/generated/api.schemas";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { X, Search, Check, AlertCircle } from "lucide-react";

export default function Compare() {
  const { compareIds, removeCollege } = useCompare();
  const [colleges, setColleges] = useState<College[]>([]);
  const { mutate: fetchCompare, isPending } = useCompareColleges();

  useEffect(() => {
    if (compareIds.length > 0) {
      fetchCompare({ data: { ids: compareIds } }, {
        onSuccess: (data) => {
          setColleges(data);
        }
      });
    } else {
      setColleges([]);
    }
  }, [compareIds, fetchCompare]);

  if (compareIds.length === 0) {
    return (
      <div className="container mx-auto px-4 py-24 text-center max-w-2xl">
        <div className="mb-8 inline-flex items-center justify-center w-24 h-24 bg-blue-50 text-primary rounded-full shadow-sm">
          <AlertCircle className="w-10 h-10" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tighter mb-6 text-foreground">Nothing to compare</h1>
        <p className="text-xl text-muted-foreground mb-10">Select at least two colleges while browsing to see them side-by-side.</p>
        <Link href="/colleges">
          <Button size="lg" className="h-16 px-10 font-bold uppercase tracking-widest btn-gradient rounded-lg shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
            <Search className="mr-2 h-5 w-5" /> Find Colleges
          </Button>
        </Link>
      </div>
    );
  }

  // Ensure we have slots up to 3
  const slots = Array.from({ length: 3 }).map((_, i) => colleges[i] || null);

  return (
    <div className="container mx-auto px-4 py-12 pb-32">
      <div className="mb-12 border-l-4 border-primary pl-6 pb-2">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tighter mb-4 text-foreground">Compare Colleges</h1>
        <p className="text-xl text-muted-foreground">Side-by-side analysis of your top choices.</p>
      </div>

      <div className="overflow-x-auto bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="min-w-[800px]">
          {/* Header Row */}
          <div className="grid grid-cols-4 gap-6 mb-8">
            <div className="col-span-1 pt-8">
              <h3 className="font-semibold uppercase tracking-widest text-sm text-muted-foreground">Institution</h3>
            </div>
            {slots.map((college, i) => (
              <div key={i} className="col-span-1 rounded-xl border border-gray-100 bg-white p-4 relative min-h-[200px] flex flex-col shadow-sm hover:shadow-md transition-all duration-300">
                {isPending && compareIds[i] ? (
                  <Skeleton className="w-full h-full bg-blue-50 rounded-lg" />
                ) : college ? (
                  <>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => removeCollege(college.id)}
                      className="absolute top-2 right-2 text-gray-400 hover:text-destructive hover:bg-destructive/10 rounded-full z-10"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                    <div className="w-16 h-16 rounded-lg bg-gray-50 border border-gray-100 mb-4 overflow-hidden shadow-sm">
                      {college.imageUrl ? (
                        <img src={college.imageUrl} alt={college.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center font-bold text-xl text-gray-300">
                          {college.name.substring(0,2)}
                        </div>
                      )}
                    </div>
                    <Link href={`/colleges/${college.id}`}>
                      <h3 className="font-bold text-xl leading-tight mb-2 hover:text-primary transition-colors">{college.name}</h3>
                    </Link>
                    <p className="text-sm font-medium text-muted-foreground">{college.location}, {college.state}</p>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center border-2 border-dashed border-blue-200 bg-blue-50/50 p-6 rounded-lg">
                    <span className="font-semibold text-sm uppercase tracking-widest text-blue-400 mb-4">Empty Slot</span>
                    <Link href="/colleges">
                      <Button variant="outline" className="border-blue-200 text-blue-600 font-semibold tracking-wide rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors">
                        Add College
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Comparison Rows */}
          {colleges.length > 0 && !isPending && (
            <div className="space-y-2 text-sm">
              <ComparisonRow 
                label="Acceptance Rate" 
                colleges={slots} 
                getValue={(c) => `${c.acceptanceRate}%`} 
                highlightBest={(vals) => Math.max(...vals.map(v => parseFloat(v)))} // Just visual, lower is harder, higher is easier
              />
              <ComparisonRow 
                label="National Rank" 
                colleges={slots} 
                getValue={(c) => `#${c.ranking}`} 
              />
              <ComparisonRow 
                label="Tuition (Annual)" 
                colleges={slots} 
                getValue={(c) => `$${c.tuition.toLocaleString()}`} 
              />
              <ComparisonRow 
                label="Enrollment" 
                colleges={slots} 
                getValue={(c) => c.enrollment.toLocaleString()} 
              />
              <ComparisonRow 
                label="SAT Range" 
                colleges={slots} 
                getValue={(c) => `${c.sat.min} - ${c.sat.max}`} 
              />
              <ComparisonRow 
                label="ACT Range" 
                colleges={slots} 
                getValue={(c) => `${c.act.min} - ${c.act.max}`} 
              />
              <ComparisonRow 
                label="Graduation Rate" 
                colleges={slots} 
                getValue={(c) => `${c.graduationRate}%`} 
              />
              <ComparisonRow 
                label="Setting & Size" 
                colleges={slots} 
                getValue={(c) => <span className="capitalize">{c.setting}, {c.campusSize}</span>} 
              />
              <ComparisonRow 
                label="Type" 
                colleges={slots} 
                getValue={(c) => <span className="capitalize">{c.type.replace('-', ' ')}</span>} 
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ComparisonRow({ 
  label, 
  colleges, 
  getValue,
  highlightBest
}: { 
  label: string, 
  colleges: (College | null)[], 
  getValue: (c: College) => React.ReactNode | string,
  highlightBest?: (values: string[]) => number
}) {
  return (
    <div className="grid grid-cols-4 gap-6 border-b border-gray-100 py-4 items-center hover:bg-gray-50/50 transition-colors rounded-lg px-2">
      <div className="col-span-1 font-semibold text-muted-foreground uppercase tracking-widest text-xs">
        {label}
      </div>
      {colleges.map((college, i) => (
        <div key={i} className="col-span-1 font-medium text-foreground">
          {college ? getValue(college) : <span className="text-gray-300">-</span>}
        </div>
      ))}
    </div>
  );
}
