import { useParams, Link } from "wouter";
import { useGetCollege, getGetCollegeQueryKey, useAddFavorite, useRemoveFavorite, useGetFavorites, getGetFavoritesQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Users, Award, Percent, Heart, Target, BookOpen, ExternalLink, Compass } from "lucide-react";
import { useCompare } from "@/context/compare-context";
import { useQueryClient } from "@tanstack/react-query";

export default function Detail() {
  const { id } = useParams<{ id: string }>();
  const collegeId = parseInt(id || "0", 10);
  const queryClient = useQueryClient();

  const { data: college, isLoading } = useGetCollege(collegeId, {
    query: {
      enabled: !!collegeId,
      queryKey: getGetCollegeQueryKey(collegeId),
    }
  });

  const { data: favorites } = useGetFavorites();
  const isFavorite = favorites?.some(f => f.collegeId === collegeId);
  const addFavorite = useAddFavorite();
  const removeFavorite = useRemoveFavorite();

  const { addCollege, removeCollege, compareIds } = useCompare();
  const isComparing = compareIds.includes(collegeId);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="h-8 w-24 mb-8 rounded-lg bg-blue-50" />
        <Skeleton className="h-64 md:h-96 w-full mb-8 rounded-xl bg-blue-50" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-2 space-y-4">
            <Skeleton className="h-12 w-3/4 rounded-lg bg-blue-50" />
            <Skeleton className="h-6 w-1/2 rounded-md bg-blue-50" />
            <Skeleton className="h-32 w-full mt-8 rounded-lg bg-blue-50" />
          </div>
          <div className="space-y-4">
            <Skeleton className="h-64 w-full rounded-xl bg-blue-50" />
          </div>
        </div>
      </div>
    );
  }

  if (!college) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <h1 className="text-4xl font-bold tracking-tighter mb-4 text-foreground">College Not Found</h1>
        <p className="text-xl text-muted-foreground mb-8">The institution you're looking for doesn't exist.</p>
        <Link href="/colleges">
          <Button className="font-semibold tracking-wide rounded-lg h-12 px-8 btn-gradient shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300">Back to Search</Button>
        </Link>
      </div>
    );
  }

  const toggleFavorite = () => {
    const action = isFavorite ? removeFavorite : addFavorite;
    action.mutate({ collegeId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetFavoritesQueryKey() });
      }
    });
  };

  const toggleCompare = () => {
    if (isComparing) {
      removeCollege(collegeId);
    } else {
      addCollege(collegeId);
    }
  };

  const schoolColor = college.color || '#2563eb';

  return (
    <div className="pb-32 bg-background">
      {/* Top Bar Accent */}
      <div className="h-1.5 w-full bg-gradient-to-r" style={{ backgroundImage: `linear-gradient(to right, ${schoolColor}, ${schoolColor}99)` }} />

      <div className="container mx-auto px-4 py-6">
        <Link href="/colleges" className="inline-flex items-center text-sm font-semibold tracking-wide text-muted-foreground hover:text-primary transition-colors mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Search
        </Link>

        {/* Hero Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="aspect-[21/9] rounded-2xl border border-gray-100 relative overflow-hidden bg-gray-50 group shadow-sm">
              {college.imageUrl ? (
                <img src={college.imageUrl} alt={college.name} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Compass className="h-32 w-32 text-gray-200" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 via-gray-900/40 to-transparent flex flex-col justify-end p-8">
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-white/20 backdrop-blur-md text-white border border-white/20 text-xs font-semibold px-3 py-1.5 rounded-full uppercase tracking-wider">
                    {college.type}
                  </span>
                  <span className="bg-white/20 backdrop-blur-md text-white border border-white/20 text-xs font-semibold px-3 py-1.5 rounded-full uppercase tracking-wider flex items-center">
                    <MapPin size={12} className="mr-1.5" /> {college.location}, {college.state}
                  </span>
                </div>
                <h1 className="text-4xl md:text-6xl font-bold text-white tracking-tighter leading-tight drop-shadow-sm">{college.name}</h1>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="rounded-2xl border border-gray-100 p-6 bg-white shadow-sm h-full flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground mb-6">Quick Actions</h3>
                <div className="space-y-4">
                  <Button 
                    onClick={toggleFavorite}
                    variant={isFavorite ? "default" : "outline"}
                    className={`w-full h-14 justify-start font-semibold text-base tracking-wide rounded-xl border transition-all duration-300 ${isFavorite ? 'bg-red-50 text-red-500 border-red-100 hover:bg-red-100 shadow-sm' : 'border-gray-200 text-foreground hover:border-primary/30 hover:text-primary hover:shadow-md hover:-translate-y-0.5'}`}
                  >
                    <Heart className={`mr-3 h-5 w-5 ${isFavorite ? 'fill-current text-red-500' : ''}`} />
                    {isFavorite ? 'Saved to Favorites' : 'Save to Favorites'}
                  </Button>
                  
                  <Button 
                    onClick={toggleCompare}
                    variant={isComparing ? "default" : "outline"}
                    className={`w-full h-14 justify-start font-semibold text-base tracking-wide rounded-xl border transition-all duration-300 ${isComparing ? 'bg-primary/10 text-primary border-primary/20 hover:bg-primary/20 shadow-sm' : 'border-gray-200 text-foreground hover:border-primary/30 hover:text-primary hover:shadow-md hover:-translate-y-0.5'}`}
                  >
                    <Target className="mr-3 h-5 w-5" />
                    {isComparing ? 'Added to Compare' : 'Add to Compare'}
                  </Button>

                  {college.website && (
                    <a href={college.website} target="_blank" rel="noopener noreferrer" className="block">
                      <Button variant="outline" className="w-full h-14 justify-start font-semibold text-base tracking-wide rounded-xl border border-gray-200 text-foreground hover:border-primary/30 hover:text-primary hover:shadow-md hover:-translate-y-0.5 transition-all duration-300">
                        <ExternalLink className="mr-3 h-5 w-5" /> Visit Website
                      </Button>
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          <div className="rounded-2xl border border-gray-100 p-6 bg-white shadow-sm flex flex-col justify-center hover:shadow-md transition-shadow">
            <div className="flex items-center text-sky-600 mb-2 font-semibold text-sm uppercase tracking-wide">
              <Award className="mr-2 h-4 w-4" /> National Rank
            </div>
            <div className="text-4xl font-bold tracking-tighter text-foreground">#{college.ranking}</div>
          </div>
          <div className="rounded-2xl border border-gray-100 p-6 bg-white shadow-sm flex flex-col justify-center hover:shadow-md transition-shadow">
            <div className="flex items-center text-blue-600 mb-2 font-semibold text-sm uppercase tracking-wide">
              <Percent className="mr-2 h-4 w-4" /> Acceptance
            </div>
            <div className="text-4xl font-bold tracking-tighter text-foreground">{college.acceptanceRate}%</div>
          </div>
          <div className="rounded-2xl border border-gray-100 p-6 bg-white shadow-sm flex flex-col justify-center hover:shadow-md transition-shadow">
            <div className="flex items-center text-purple-600 mb-2 font-semibold text-sm uppercase tracking-wide">
              <Users className="mr-2 h-4 w-4" /> Enrollment
            </div>
            <div className="text-4xl font-bold tracking-tighter text-foreground">{(college.enrollment / 1000).toFixed(1)}k</div>
          </div>
          <div className="rounded-2xl border border-gray-100 p-6 bg-white shadow-sm flex flex-col justify-center hover:shadow-md transition-shadow">
            <div className="flex items-center text-emerald-600 mb-2 font-semibold text-sm uppercase tracking-wide">
              Tuition / Year
            </div>
            <div className="text-4xl font-bold tracking-tighter text-foreground">${(college.tuition / 1000).toFixed(1)}k</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <section>
              <h2 className="text-3xl font-bold tracking-tighter mb-6 pl-4 border-l-4 border-primary text-foreground">About</h2>
              <p className="text-lg leading-relaxed text-muted-foreground">{college.description}</p>
            </section>

            <section>
              <h2 className="text-3xl font-bold tracking-tighter mb-6 pl-4 border-l-4 border-primary text-foreground">Campus Life</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-xl border border-gray-100 bg-white p-5 flex justify-between items-center shadow-sm hover:shadow-md transition-shadow">
                  <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Setting</span>
                  <span className="font-bold text-lg capitalize text-foreground">{college.setting}</span>
                </div>
                <div className="rounded-xl border border-gray-100 bg-white p-5 flex justify-between items-center shadow-sm hover:shadow-md transition-shadow">
                  <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Size</span>
                  <span className="font-bold text-lg capitalize text-foreground">{college.campusSize}</span>
                </div>
                <div className="rounded-xl border border-gray-100 bg-white p-5 flex justify-between items-center shadow-sm hover:shadow-md transition-shadow">
                  <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Founded</span>
                  <span className="font-bold text-lg text-foreground">{college.founded}</span>
                </div>
                <div className="rounded-xl border border-gray-100 bg-white p-5 flex justify-between items-center shadow-sm hover:shadow-md transition-shadow">
                  <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Grad Rate</span>
                  <span className="font-bold text-lg text-foreground">{college.graduationRate}%</span>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold tracking-tighter mb-6 pl-4 border-l-4 border-primary text-foreground">Top Programs</h2>
              <div className="flex flex-wrap gap-3">
                {college.programs.map((program, index) => {
                  const colorClasses = [
                    "bg-blue-50 text-blue-700 border-blue-100",
                    "bg-purple-50 text-purple-700 border-purple-100",
                    "bg-sky-50 text-sky-700 border-sky-100"
                  ];
                  const colorClass = colorClasses[index % colorClasses.length];
                  return (
                    <span key={index} className={`border px-5 py-2.5 font-semibold flex items-center rounded-full shadow-sm ${colorClass}`}>
                      <BookOpen size={16} className="mr-2 opacity-70" /> {program}
                    </span>
                  );
                })}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div>
            <div className="rounded-2xl border border-gray-100 p-8 bg-white shadow-sm sticky top-24">
              <h3 className="text-2xl font-bold tracking-tighter mb-8 text-foreground">Admissions</h3>
              
              <div className="space-y-8">
                <div>
                  <div className="flex justify-between items-end mb-3">
                    <span className="font-bold text-lg text-foreground">SAT Range</span>
                    <span className="font-medium text-sm text-primary">{college.sat.min} - {college.sat.max}</span>
                  </div>
                  <div className="h-3 w-full bg-blue-50 rounded-full relative overflow-hidden">
                    <div 
                      className="absolute h-full top-0 rounded-full" 
                      style={{ 
                        left: `${((college.sat.min - 400) / 1200) * 100}%`, 
                        right: `${100 - ((college.sat.max - 400) / 1200) * 100}%`,
                        backgroundColor: schoolColor
                      }} 
                    />
                  </div>
                  <div className="flex justify-between mt-2 text-xs font-medium text-muted-foreground">
                    <span>400</span>
                    <span>1600</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-end mb-3">
                    <span className="font-bold text-lg text-foreground">ACT Range</span>
                    <span className="font-medium text-sm text-primary">{college.act.min} - {college.act.max}</span>
                  </div>
                  <div className="h-3 w-full bg-blue-50 rounded-full relative overflow-hidden">
                    <div 
                      className="absolute h-full top-0 rounded-full" 
                      style={{ 
                        left: `${((college.act.min - 1) / 35) * 100}%`, 
                        right: `${100 - ((college.act.max - 1) / 35) * 100}%`,
                        backgroundColor: schoolColor
                      }} 
                    />
                  </div>
                  <div className="flex justify-between mt-2 text-xs font-medium text-muted-foreground">
                    <span>1</span>
                    <span>36</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
