import { useState } from "react";
import { useLocation } from "wouter";
import { useSubmitQuiz } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowLeft, Sparkles, RotateCcw, ExternalLink } from "lucide-react";
import { Link } from "wouter";

type QuizAnswers = {
  interests: string[];
  budget: string;
  setting: string;
  campusSize: string;
  selectivity: string;
  schoolType: string;
};

const INTEREST_OPTIONS = [
  "Computer Science", "Engineering", "Business", "Medicine",
  "Law", "Economics", "Biology", "Mathematics",
  "Arts & Design", "Political Science", "Architecture", "Journalism",
  "Public Policy", "Liberal Arts", "Music", "Film & Television",
];

const STEPS = [
  { id: "interests", title: "What are you passionate about?", subtitle: "Select all fields that interest you" },
  { id: "budget",    title: "What's your annual budget?",    subtitle: "Tuition costs vary widely — pick your range" },
  { id: "setting",   title: "Where do you want to be?",      subtitle: "Campus environment shapes your daily life" },
  { id: "campusSize",title: "How big should your campus be?",subtitle: "Size affects community feel and class sizes" },
  { id: "selectivity","title": "How selective are you aiming for?", subtitle: "Be honest — it's your future"},
  { id: "schoolType","title": "What type of school fits you?",subtitle: "Each has a distinct culture and identity" },
];

type QuizResult = {
  college: {
    id: number; name: string; location: string; state: string; type: string;
    ranking: number; acceptanceRate: number; tuition: number; enrollment: number;
    imageUrl: string; programs: string[]; color: string | null; website: string | null;
  };
  matchScore: number;
  reasons: string[];
};

export default function QuizPage() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswers>({
    interests: [], budget: "", setting: "", campusSize: "", selectivity: "", schoolType: "",
  });
  const [results, setResults] = useState<QuizResult[] | null>(null);

  const submitQuiz = useSubmitQuiz();

  const currentStep = STEPS[step];
  const totalSteps = STEPS.length;
  const progress = ((step) / totalSteps) * 100;

  const canAdvance = () => {
    switch (currentStep.id) {
      case "interests":   return answers.interests.length > 0;
      case "budget":      return !!answers.budget;
      case "setting":     return !!answers.setting;
      case "campusSize":  return !!answers.campusSize;
      case "selectivity": return !!answers.selectivity;
      case "schoolType":  return !!answers.schoolType;
      default: return false;
    }
  };

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setStep(s => s + 1);
    } else {
      submitQuiz.mutate(
        { data: answers },
        { onSuccess: (data) => setResults(data as QuizResult[]) }
      );
    }
  };

  const handleBack = () => setStep(s => s - 1);

  const handleReset = () => {
    setResults(null);
    setStep(0);
    setAnswers({ interests: [], budget: "", setting: "", campusSize: "", selectivity: "", schoolType: "" });
  };

  const toggleInterest = (val: string) => {
    setAnswers(prev => ({
      ...prev,
      interests: prev.interests.includes(val)
        ? prev.interests.filter(i => i !== val)
        : [...prev.interests, val],
    }));
  };

  const setOption = (field: keyof QuizAnswers, val: string) => {
    setAnswers(prev => ({ ...prev, [field]: val }));
  };

  // ─── Results View ────────────────────────────────────────────────────────────
  if (results) {
    return (
      <div className="min-h-screen bg-background">
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e3a8a] text-white py-20 px-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.apply/noise.svg')] opacity-20 mix-blend-overlay"></div>
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff1a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff1a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
          <div className="container mx-auto max-w-4xl relative z-10 text-center">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-1.5 mb-6 text-sm font-semibold tracking-wide uppercase text-white rounded-full">
              <Sparkles size={14} /> Your Matches Are Ready
            </div>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tighter mb-4">
              {results[0]?.matchScore ?? 0}% Match
              <span className="bg-gradient-to-r from-blue-200 to-white bg-clip-text text-transparent"> on your top pick</span>
            </h1>
            <p className="text-lg text-blue-100/80">Based on your interests, budget, and campus preferences</p>
          </div>
        </div>

        <div className="container mx-auto max-w-4xl px-4 py-16">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-2xl font-bold tracking-tighter text-foreground border-l-4 border-primary pl-4">Top Recommendations</h2>
            <Button variant="outline" className="border-gray-200 font-semibold tracking-wide shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 rounded-lg text-muted-foreground hover:text-foreground" onClick={handleReset}>
              <RotateCcw size={16} className="mr-2" /> Retake Quiz
            </Button>
          </div>

          <div className="flex flex-col gap-6">
            {results.map((result, idx) => (
              <div key={result.college.id} className="rounded-xl border border-gray-100 bg-white shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 overflow-hidden relative">
                <div className="absolute top-0 bottom-0 left-0 w-1.5" style={{ backgroundColor: result.college.color || "hsl(224 71% 51%)" }} />
                <div className="p-6 pl-8 flex flex-col md:flex-row gap-6">
                  {/* Rank + Score */}
                  <div className="flex md:flex-col items-center md:items-start gap-4 md:gap-2 md:min-w-[80px]">
                    <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
                      #{idx + 1}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-3xl font-bold leading-none text-foreground">{result.matchScore}%</span>
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mt-1">Match</span>
                    </div>
                  </div>

                  {/* Match bar */}
                  <div className="hidden md:block w-px bg-gray-100 mx-2" />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-3 flex-wrap">
                      <div>
                        <h3 className="text-xl font-bold leading-tight text-foreground">{result.college.name}</h3>
                        <p className="text-sm font-medium text-muted-foreground mt-1">
                          {result.college.location} · Rank #{result.college.ranking}
                        </p>
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <Link href={`/colleges/${result.college.id}`}>
                          <Button className="btn-gradient font-bold tracking-wide shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 rounded-lg">
                            View Details <ArrowRight size={14} className="ml-1" />
                          </Button>
                        </Link>
                      </div>
                    </div>

                    {/* Match score bar */}
                    <div className="w-full h-2 rounded-full bg-gray-100 mb-5 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-700"
                        style={{ width: `${result.matchScore}%` }}
                      />
                    </div>

                    {/* Reasons */}
                    <div className="flex flex-wrap gap-2">
                      {result.reasons.map((reason, i) => (
                        <span key={i} className="inline-block px-3 py-1.5 rounded-full text-xs font-semibold text-primary bg-primary/10">
                          {reason}
                        </span>
                      ))}
                    </div>

                    {/* Quick stats */}
                    <div className="mt-5 pt-4 border-t border-gray-100 flex flex-wrap gap-6 text-sm text-muted-foreground">
                      <span><strong className="text-foreground">{result.college.acceptanceRate}%</strong> acceptance</span>
                      <span><strong className="text-foreground">${(result.college.tuition / 1000).toFixed(0)}k</strong>/year</span>
                      <span><strong className="text-foreground">{(result.college.enrollment / 1000).toFixed(1)}k</strong> students</span>
                      <span className="px-2.5 py-0.5 rounded-md text-xs font-bold uppercase bg-gray-100 text-gray-600">
                        {result.college.type === "private" ? "Private" : result.college.type === "public" ? "Public" : "Liberal Arts"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <p className="text-muted-foreground mb-6 font-semibold uppercase tracking-widest text-sm">Want to dig deeper?</p>
            <Button size="lg" variant="outline" className="h-14 px-10 border-gray-200 text-primary font-bold tracking-wide shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 rounded-xl bg-white hover:bg-gray-50" onClick={() => setLocation("/colleges")}>
              Browse All Colleges <ArrowRight size={18} className="ml-2" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // ─── Quiz View ───────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0f172a] to-[#1e3a8a] text-white py-12 px-4 relative overflow-hidden shadow-sm">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.apply/noise.svg')] opacity-20 mix-blend-overlay"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff1a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff1a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
        <div className="container mx-auto max-w-2xl relative z-10 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-1.5 mb-5 text-sm font-semibold tracking-wide uppercase text-white rounded-full">
            <Sparkles size={14} /> College Match Quiz
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tighter">
            Find your perfect fit.
          </h1>
          <p className="mt-3 text-blue-100/70 font-medium">6 questions · Under 2 minutes</p>
        </div>
      </div>

      {/* Progress */}
      <div className="w-full h-1.5 bg-gray-100">
        <div
          className="h-full bg-primary transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="container mx-auto max-w-2xl px-4 pt-4 pb-0">
        <div className="flex justify-between text-xs font-semibold text-muted-foreground uppercase tracking-widest">
          <span>Step {step + 1} of {totalSteps}</span>
          <span className="text-primary">{Math.round(progress)}% complete</span>
        </div>
      </div>

      {/* Step Content */}
      <div className="flex-1 container mx-auto max-w-2xl px-4 py-12">
        <div className="mb-10 text-center">
          <h2 className="text-3xl font-bold tracking-tighter mb-3 text-foreground">{currentStep.title}</h2>
          <p className="text-muted-foreground text-lg">{currentStep.subtitle}</p>
        </div>

        {/* Interests */}
        {currentStep.id === "interests" && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {INTEREST_OPTIONS.map((opt) => {
              const selected = answers.interests.includes(opt);
              return (
                <button
                  key={opt}
                  onClick={() => toggleInterest(opt)}
                  className={`p-4 text-center font-semibold text-sm rounded-xl transition-all duration-300 hover:-translate-y-1 ${
                    selected
                      ? "bg-gradient-to-br from-primary to-secondary text-white shadow-md border-transparent"
                      : "bg-white border border-gray-200 text-foreground hover:border-primary/40 hover:shadow-sm"
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
        )}

        {/* Budget */}
        {currentStep.id === "budget" && (
          <div className="flex flex-col gap-4">
            {[
              { value: "under30k", label: "Under $30,000 / year", sub: "Best for public in-state options" },
              { value: "30k-50k",  label: "$30,000 – $50,000 / year", sub: "Competitive public & some private" },
              { value: "50k-65k",  label: "$50,000 – $65,000 / year", sub: "Top private universities" },
              { value: "any",      label: "No budget limit",  sub: "Show me everything" },
            ].map((opt) => (
              <OptionCard key={opt.value} selected={answers.budget === opt.value} onClick={() => setOption("budget", opt.value)} label={opt.label} sub={opt.sub} />
            ))}
          </div>
        )}

        {/* Setting */}
        {currentStep.id === "setting" && (
          <div className="flex flex-col gap-4">
            {[
              { value: "urban",    label: "Urban",    sub: "City life, transit, endless things to do" },
              { value: "suburban", label: "Suburban", sub: "Best of both worlds" },
              { value: "rural",    label: "Rural",    sub: "Tight community, nature, focus" },
              { value: "any",      label: "No preference", sub: "Any campus environment" },
            ].map((opt) => (
              <OptionCard key={opt.value} selected={answers.setting === opt.value} onClick={() => setOption("setting", opt.value)} label={opt.label} sub={opt.sub} />
            ))}
          </div>
        )}

        {/* Campus size */}
        {currentStep.id === "campusSize" && (
          <div className="flex flex-col gap-4">
            {[
              { value: "small",  label: "Small",   sub: "Under 5,000 students — intimate, close faculty access" },
              { value: "medium", label: "Medium",  sub: "5,000–20,000 students — variety without feeling lost" },
              { value: "large",  label: "Large",   sub: "20,000+ students — resources, diversity, big culture" },
              { value: "any",    label: "No preference", sub: "Any campus size works for me" },
            ].map((opt) => (
              <OptionCard key={opt.value} selected={answers.campusSize === opt.value} onClick={() => setOption("campusSize", opt.value)} label={opt.label} sub={opt.sub} />
            ))}
          </div>
        )}

        {/* Selectivity */}
        {currentStep.id === "selectivity" && (
          <div className="flex flex-col gap-4">
            {[
              { value: "highly-selective", label: "Highly Selective", sub: "Under 10% acceptance rate — I'm aiming for the top" },
              { value: "selective",        label: "Selective",        sub: "10%–30% acceptance rate — competitive but attainable" },
              { value: "any",              label: "Open to all",       sub: "Acceptance rate is not a priority for me" },
            ].map((opt) => (
              <OptionCard key={opt.value} selected={answers.selectivity === opt.value} onClick={() => setOption("selectivity", opt.value)} label={opt.label} sub={opt.sub} />
            ))}
          </div>
        )}

        {/* School type */}
        {currentStep.id === "schoolType" && (
          <div className="flex flex-col gap-4">
            {[
              { value: "private",      label: "Private",       sub: "Typically smaller, higher tuition, strong endowments" },
              { value: "public",       label: "Public",        sub: "State-funded, larger, often great value" },
              { value: "liberal-arts", label: "Liberal Arts",  sub: "Small, interdisciplinary, writing and critical thinking" },
              { value: "any",          label: "No preference", sub: "Any type of institution" },
            ].map((opt) => (
              <OptionCard key={opt.value} selected={answers.schoolType === opt.value} onClick={() => setOption("schoolType", opt.value)} label={opt.label} sub={opt.sub} />
            ))}
          </div>
        )}

        {/* Navigation */}
        <div className="flex justify-between items-center mt-12 pt-8 border-t border-gray-100">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 0}
            className="h-14 px-8 border-gray-200 text-muted-foreground font-semibold tracking-wide rounded-xl shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-30 disabled:pointer-events-none hover:bg-gray-50 hover:text-foreground"
          >
            <ArrowLeft size={18} className="mr-2" /> Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={!canAdvance() || submitQuiz.isPending}
            className="h-14 px-10 btn-gradient text-white font-bold tracking-wide rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-30 disabled:pointer-events-none"
          >
            {submitQuiz.isPending ? "Calculating..." : step === totalSteps - 1 ? (
              <><Sparkles size={18} className="mr-2" /> Get My Matches</>
            ) : (
              <>Next <ArrowRight size={18} className="ml-2" /></>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

function OptionCard({
  selected, onClick, label, sub,
}: { selected: boolean; onClick: () => void; label: string; sub: string }) {
  return (
    <button
      onClick={onClick}
      className={`p-6 rounded-xl text-left transition-all duration-300 hover:-translate-y-1 w-full flex flex-col justify-center border ${
        selected
          ? "bg-primary/5 border-primary shadow-sm"
          : "bg-white border-gray-200 hover:border-primary/40 hover:shadow-sm"
      }`}
    >
      <div className={`font-bold text-lg ${selected ? "text-primary" : "text-foreground"}`}>{label}</div>
      <div className={`text-sm mt-1 font-medium ${selected ? "text-primary/70" : "text-muted-foreground"}`}>{sub}</div>
    </button>
  );
}
