import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Search as SearchIcon, Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CollegeCard } from "@/components/college/college-card";
import { useListColleges, getListCollegesQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetClose, SheetFooter } from "@/components/ui/sheet";

export default function Search() {
  const [location, setLocation] = useLocation();
  
  // Parse URL search params
  const searchParams = new URLSearchParams(window.location.search);
  
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [type, setType] = useState(searchParams.get("type") || "all");
  const [stateFilter, setStateFilter] = useState(searchParams.get("state") || "all");
  const [acceptanceRange, setAcceptanceRange] = useState([
    parseInt(searchParams.get("minAcceptance") || "0"),
    parseInt(searchParams.get("maxAcceptance") || "100")
  ]);

  // Sync state to URL
  useEffect(() => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (type !== "all") params.set("type", type);
    if (stateFilter !== "all") params.set("state", stateFilter);
    if (acceptanceRange[0] > 0) params.set("minAcceptance", acceptanceRange[0].toString());
    if (acceptanceRange[1] < 100) params.set("maxAcceptance", acceptanceRange[1].toString());
    
    const newSearch = params.toString();
    const newUrl = newSearch ? `/colleges?${newSearch}` : "/colleges";
    
    // Only update if changed to avoid loops
    if (window.location.search !== `?${newSearch}` && (window.location.search !== "" || newSearch !== "")) {
      setLocation(newUrl, { replace: true });
    }
  }, [search, type, stateFilter, acceptanceRange, setLocation]);

  const { data: colleges, isLoading } = useListColleges(
    {
      search: search || undefined,
      type: type !== "all" ? type : undefined,
      state: stateFilter !== "all" ? stateFilter : undefined,
      minAcceptance: acceptanceRange[0] > 0 ? acceptanceRange[0] : undefined,
      maxAcceptance: acceptanceRange[1] < 100 ? acceptanceRange[1] : undefined,
    },
    {
      query: {
        queryKey: getListCollegesQueryKey({
          search: search || undefined,
          type: type !== "all" ? type : undefined,
          state: stateFilter !== "all" ? stateFilter : undefined,
          minAcceptance: acceptanceRange[0] > 0 ? acceptanceRange[0] : undefined,
          maxAcceptance: acceptanceRange[1] < 100 ? acceptanceRange[1] : undefined,
        }),
        keepPreviousData: true,
      }
    }
  );

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setStateFilter("all");
    setAcceptanceRange([0, 100]);
  };

  const hasActiveFilters = search || type !== "all" || stateFilter !== "all" || acceptanceRange[0] > 0 || acceptanceRange[1] < 100;

  const states = ["CA", "NY", "MA", "TX", "IL", "PA", "OH", "MI", "FL", "NJ"]; // Mock state list

  const FiltersContent = () => (
    <div className="space-y-8">
      <div className="space-y-3">
        <Label className="font-semibold uppercase tracking-widest text-xs text-muted-foreground">Search</Label>
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="College name..." 
            className="pl-9 border-gray-200 rounded-lg h-12 focus-visible:ring-primary focus-visible:border-primary transition-all duration-300 shadow-sm"
          />
        </div>
      </div>

      <div className="space-y-3">
        <Label className="font-semibold uppercase tracking-widest text-xs text-muted-foreground">Institution Type</Label>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="border-gray-200 rounded-lg h-12 shadow-sm focus:ring-primary">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent className="border-gray-200 rounded-lg shadow-lg">
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="public">Public</SelectItem>
            <SelectItem value="private">Private</SelectItem>
            <SelectItem value="liberal-arts">Liberal Arts</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        <Label className="font-semibold uppercase tracking-widest text-xs text-muted-foreground">State</Label>
        <Select value={stateFilter} onValueChange={setStateFilter}>
          <SelectTrigger className="border-gray-200 rounded-lg h-12 shadow-sm focus:ring-primary">
            <SelectValue placeholder="All States" />
          </SelectTrigger>
          <SelectContent className="border-gray-200 rounded-lg shadow-lg max-h-60">
            <SelectItem value="all">All States</SelectItem>
            {states.map(s => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Label className="font-semibold uppercase tracking-widest text-xs text-muted-foreground">Acceptance Rate</Label>
          <span className="font-medium text-sm text-primary">{acceptanceRange[0]}% - {acceptanceRange[1]}%</span>
        </div>
        <Slider
          value={acceptanceRange}
          onValueChange={setAcceptanceRange}
          max={100}
          step={1}
          className="py-4"
        />
      </div>

      {hasActiveFilters && (
        <Button 
          variant="outline" 
          onClick={clearFilters}
          className="w-full border-gray-200 text-muted-foreground font-semibold tracking-wide rounded-lg h-12 hover:bg-gray-50 hover:text-foreground transition-all duration-300"
        >
          Clear All Filters
        </Button>
      )}
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        
        {/* Desktop Sidebar */}
        <div className="hidden md:block w-72 shrink-0">
          <div className="sticky top-24 bg-white p-6 rounded-xl border border-gray-100 shadow-[0_2px_8px_rgba(0,0,0,0.06)]">
            <div className="mb-6 pb-4 border-b border-gray-100">
              <h2 className="text-2xl font-bold tracking-tighter text-foreground">Filters</h2>
            </div>
            <FiltersContent />
          </div>
        </div>

        {/* Mobile Filter Sheet */}
        <div className="md:hidden mb-4 flex justify-between items-center">
          <h1 className="text-3xl font-bold tracking-tighter text-foreground border-l-4 border-primary pl-4">Colleges</h1>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="border-gray-200 rounded-lg font-semibold tracking-wide shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300">
                <Filter className="mr-2 h-4 w-4" /> Filters
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-full sm:max-w-md border-r border-gray-100 rounded-none bg-white">
              <SheetHeader className="text-left border-b border-gray-100 pb-4 mb-6">
                <SheetTitle className="text-2xl font-bold tracking-tighter">Filters</SheetTitle>
              </SheetHeader>
              <div className="pb-20">
                <FiltersContent />
              </div>
              <SheetFooter className="absolute bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-100">
                <SheetClose asChild>
                  <Button className="w-full h-14 btn-gradient text-white font-bold tracking-wide rounded-lg shadow-md">
                    Show Results
                  </Button>
                </SheetClose>
              </SheetFooter>
            </SheetContent>
          </Sheet>
        </div>

        {/* Results Area */}
        <div className="flex-1 pb-24">
          <div className="hidden md:flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
            <div className="border-l-4 border-primary pl-4">
              <h1 className="text-3xl font-bold tracking-tighter text-foreground">Colleges</h1>
            </div>
            <div className="font-semibold text-sm bg-primary/10 text-primary px-3 py-1.5 rounded-full">
              {isLoading ? "..." : colleges?.length || 0} Results
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="border border-gray-100 p-4 bg-white rounded-xl shadow-sm">
                  <Skeleton className="h-48 w-full bg-blue-50 mb-4 rounded-lg" />
                  <Skeleton className="h-6 w-3/4 bg-blue-50 mb-2 rounded-md" />
                  <Skeleton className="h-4 w-1/2 bg-blue-50 rounded-md" />
                </div>
              ))
            ) : colleges && colleges.length > 0 ? (
              colleges.map((college) => (
                <CollegeCard key={college.id} college={college} />
              ))
            ) : (
              <div className="col-span-full py-24 text-center border-2 border-dashed border-blue-200 bg-blue-50/30 rounded-2xl">
                <SearchIcon className="h-12 w-12 mx-auto text-blue-300 mb-4" />
                <h3 className="text-2xl font-bold mb-2 text-foreground">No colleges found</h3>
                <p className="text-muted-foreground mb-6">Try adjusting your search or filters.</p>
                <Button 
                  onClick={clearFilters}
                  className="btn-gradient rounded-lg font-bold tracking-wide px-8 h-12 shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
