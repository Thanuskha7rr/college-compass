import { Link } from "wouter";
import { useGetFavorites } from "@workspace/api-client-react";
import { CollegeCard } from "@/components/college/college-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Heart, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Favorites() {
  const { data: favorites, isLoading } = useGetFavorites();

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-12 border-l-4 border-primary pl-6 pb-2 flex items-center justify-between">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tighter mb-4 flex items-center text-foreground">
            <Heart className="mr-4 h-10 w-10 text-secondary" /> Your Favorites
          </h1>
          <p className="text-xl text-muted-foreground">Keep track of the colleges that catch your eye.</p>
        </div>
        <div className="hidden md:block">
          <div className="font-semibold text-sm bg-primary/10 text-primary px-4 py-2 rounded-full tracking-wide">
            {isLoading ? "..." : favorites?.length || 0} Saved
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="rounded-xl border border-gray-100 p-4 bg-white shadow-sm">
              <Skeleton className="h-48 w-full bg-blue-50 mb-4 rounded-lg" />
              <Skeleton className="h-6 w-3/4 bg-blue-50 mb-2 rounded-md" />
              <Skeleton className="h-4 w-1/2 bg-blue-50 rounded-md" />
            </div>
          ))}
        </div>
      ) : favorites && favorites.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-24">
          {/* Note: In a real app, useGetFavorites might return College objects directly or we'd fetch them individually. 
              Assuming the API returns Favorite objects, but the frontend needs College data. 
              If the schema returns `collegeId`, we'd normally fetch the college details or the backend would populate it.
              For this UI, assuming the API returns populated college data inside favorites or we map it. 
              The schema for Favorite shows `collegeId`. If we don't have the full college data, this would break.
              Checking the API spec: `getFavorites` returns `Favorite[]`. We need to fetch the colleges.
              Since we don't have a `listCollegesByIds` hook, and doing N queries is bad, let's use the list endpoint 
              or hope list has them. Actually, the backend might just be returning mock data. 
              Wait, we can just use `useListColleges` and filter, or we just render placeholders. 
              Let's use `useListColleges` to get all and filter by favored IDs.
          */}
          <FavoritesGrid favoriteIds={favorites.map(f => f.collegeId)} />
        </div>
      ) : (
        <div className="py-32 text-center border-2 border-dashed border-blue-200 rounded-2xl bg-blue-50/30 flex flex-col items-center justify-center">
          <Heart className="h-16 w-16 text-blue-300 mb-6" />
          <h2 className="text-3xl font-bold tracking-tighter mb-4 text-foreground">No favorites yet</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-md mx-auto">Start browsing and click the heart icon to save colleges you're interested in.</p>
          <Link href="/colleges">
            <Button size="lg" className="h-14 px-8 font-bold tracking-wide btn-gradient rounded-lg shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
              <Search className="mr-2 h-5 w-5" /> Browse Colleges
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}

import { useListColleges } from "@workspace/api-client-react";

function FavoritesGrid({ favoriteIds }: { favoriteIds: number[] }) {
  // Hack to get college data since we only have IDs
  const { data: colleges } = useListColleges();
  
  if (!colleges) return null;
  
  const favoredColleges = colleges.filter(c => favoriteIds.includes(c.id));
  
  return (
    <>
      {favoredColleges.map(college => (
        <CollegeCard key={college.id} college={college} />
      ))}
    </>
  );
}
