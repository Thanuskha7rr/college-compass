import { Router, type IRouter } from "express";
import healthRouter from "./health";
import collegesRouter from "./colleges";
import favoritesRouter from "./favorites";
import quizRouter from "./quiz";

const router: IRouter = Router();

router.use(healthRouter);
router.use(collegesRouter);
router.use(favoritesRouter);
router.use(quizRouter);

export default router;
