import { Router } from "express";
import { db } from "@workspace/db";
import { collegesTable } from "@workspace/db";
import { SubmitQuizBody } from "@workspace/api-zod";
import type { College } from "@workspace/db";

const router = Router();

type QuizInput = {
  interests: string[];
  budget: string;
  setting: string;
  campusSize: string;
  selectivity: string;
  schoolType: string;
};

function scoreCollege(college: College, input: QuizInput): { score: number; reasons: string[] } {
  let score = 0;
  const reasons: string[] = [];
  const MAX_SCORE = 100;

  // 1. Academic interests — 35 points
  const interestPoints = 35;
  if (input.interests.length > 0) {
    const programs = college.programs as string[];
    const matched = input.interests.filter((interest) =>
      programs.some((p) => p.toLowerCase().includes(interest.toLowerCase()) || interest.toLowerCase().includes(p.toLowerCase()))
    );
    if (matched.length > 0) {
      const pts = Math.min(interestPoints, Math.round((matched.length / input.interests.length) * interestPoints));
      score += pts;
      reasons.push(`Offers programs in ${matched.slice(0, 2).join(" and ")}`);
    }
  } else {
    score += interestPoints;
  }

  // 2. Budget — 25 points
  const budgetPoints = 25;
  const tuition = college.tuition;
  let budgetMatch = false;
  switch (input.budget) {
    case "under30k":
      budgetMatch = tuition < 30000;
      break;
    case "30k-50k":
      budgetMatch = tuition >= 30000 && tuition <= 50000;
      break;
    case "50k-65k":
      budgetMatch = tuition > 50000 && tuition <= 65000;
      break;
    case "any":
    default:
      budgetMatch = true;
      break;
  }
  if (budgetMatch) {
    score += budgetPoints;
    if (input.budget !== "any") {
      reasons.push(`Tuition of $${(tuition / 1000).toFixed(0)}k fits your budget`);
    }
  } else {
    // Partial credit if close
    if (input.budget === "under30k" && tuition < 45000) {
      score += Math.round(budgetPoints * 0.4);
    } else if (input.budget === "30k-50k" && (tuition < 30000 || tuition <= 55000)) {
      score += Math.round(budgetPoints * 0.5);
    }
  }

  // 3. Campus setting — 20 points
  const settingPoints = 20;
  if (input.setting === "any" || college.setting === input.setting) {
    score += settingPoints;
    if (input.setting !== "any") {
      reasons.push(`${college.setting.charAt(0).toUpperCase() + college.setting.slice(1)} campus matches your preference`);
    }
  }

  // 4. Campus size — 10 points
  const sizePoints = 10;
  const enrollment = college.enrollment;
  let sizeMatch = false;
  switch (input.campusSize) {
    case "small":
      sizeMatch = enrollment < 5000;
      break;
    case "medium":
      sizeMatch = enrollment >= 5000 && enrollment <= 20000;
      break;
    case "large":
      sizeMatch = enrollment > 20000;
      break;
    case "any":
    default:
      sizeMatch = true;
      break;
  }
  if (sizeMatch) {
    score += sizePoints;
    if (input.campusSize !== "any") {
      const sizeLabel = enrollment < 5000 ? "Small" : enrollment <= 20000 ? "Mid-size" : "Large";
      reasons.push(`${sizeLabel} campus with ${(enrollment / 1000).toFixed(1)}k students`);
    }
  }

  // 5. Selectivity — 5 points
  const selectivityPoints = 5;
  const acceptRate = college.acceptanceRate;
  let selectMatch = false;
  switch (input.selectivity) {
    case "highly-selective":
      selectMatch = acceptRate < 10;
      break;
    case "selective":
      selectMatch = acceptRate >= 10 && acceptRate <= 30;
      break;
    case "any":
    default:
      selectMatch = true;
      break;
  }
  if (selectMatch) {
    score += selectivityPoints;
  }

  // 6. School type — 5 points
  const typePoints = 5;
  if (input.schoolType === "any" || college.type === input.schoolType) {
    score += typePoints;
    if (input.schoolType !== "any") {
      reasons.push(`${college.type.charAt(0).toUpperCase() + college.type.slice(1)} institution as preferred`);
    }
  }

  // Bonus: top-ranked schools always get a slight boost mention
  if (college.ranking <= 10) {
    reasons.push(`Ranked #${college.ranking} nationally`);
  } else if (college.ranking <= 20) {
    reasons.push(`Top-20 national ranking`);
  }

  // Clamp score
  const finalScore = Math.min(MAX_SCORE, Math.max(0, score));

  // Always return at least one reason
  if (reasons.length === 0) {
    reasons.push(`${college.name} is a strong match for your profile`);
  }

  return { score: finalScore, reasons: reasons.slice(0, 4) };
}

router.post("/quiz", async (req, res) => {
  try {
    const input = SubmitQuizBody.parse(req.body) as QuizInput;
    const colleges = await db.select().from(collegesTable).orderBy(collegesTable.ranking);

    const results = colleges
      .map((college) => {
        const { score, reasons } = scoreCollege(college, input);
        return { college, matchScore: score, reasons };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, 8);

    res.json(results);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid quiz input" });
  }
});

export default router;
