import { Router } from "express";
import { db, favoritesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { AddFavoriteParams, RemoveFavoriteParams } from "@workspace/api-zod";

const router = Router();

function getSessionId(req: any): string {
  const cookie = req.headers.cookie || "";
  const match = cookie.match(/session_id=([^;]+)/);
  if (match) return match[1];
  return "default-session";
}

router.get("/favorites", async (req, res) => {
  try {
    const sessionId = getSessionId(req);
    const favorites = await db
      .select()
      .from(favoritesTable)
      .where(eq(favoritesTable.sessionId, sessionId))
      .orderBy(favoritesTable.createdAt);

    res.json(favorites);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch favorites" });
  }
});

router.post("/favorites/:collegeId", async (req, res) => {
  try {
    const { collegeId } = AddFavoriteParams.parse({ collegeId: Number(req.params.collegeId) });
    const sessionId = getSessionId(req);

    const existing = await db
      .select()
      .from(favoritesTable)
      .where(
        and(
          eq(favoritesTable.sessionId, sessionId),
          eq(favoritesTable.collegeId, collegeId)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      res.status(201).json(existing[0]);
      return;
    }

    const [fav] = await db
      .insert(favoritesTable)
      .values({ collegeId, sessionId })
      .returning();

    res.status(201).json(fav);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.delete("/favorites/:collegeId", async (req, res) => {
  try {
    const { collegeId } = RemoveFavoriteParams.parse({ collegeId: Number(req.params.collegeId) });
    const sessionId = getSessionId(req);

    await db
      .delete(favoritesTable)
      .where(
        and(
          eq(favoritesTable.sessionId, sessionId),
          eq(favoritesTable.collegeId, collegeId)
        )
      );

    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

export default router;
