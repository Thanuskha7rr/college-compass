import { Router } from "express";
import { db } from "@workspace/db";
import { collegesTable } from "@workspace/db";
import { eq, ilike, or, and, gte, lte, inArray } from "drizzle-orm";
import { z } from "zod/v4";
import {
  ListCollegesQueryParams,
  GetCollegeParams,
  CompareCollegesBody,
} from "@workspace/api-zod";

const router = Router();

router.get("/colleges", async (req, res) => {
  try {
    const query = ListCollegesQueryParams.parse(req.query);

    const conditions: ReturnType<typeof eq>[] = [];

    if (query.search) {
      conditions.push(
        or(
          ilike(collegesTable.name, `%${query.search}%`),
          ilike(collegesTable.location, `%${query.search}%`),
          ilike(collegesTable.state, `%${query.search}%`)
        ) as unknown as ReturnType<typeof eq>
      );
    }

    if (query.type) {
      conditions.push(eq(collegesTable.type, query.type));
    }

    if (query.state) {
      conditions.push(eq(collegesTable.state, query.state));
    }

    if (query.featured !== undefined) {
      conditions.push(eq(collegesTable.featured, query.featured));
    }

    if (query.minAcceptance !== undefined) {
      conditions.push(gte(collegesTable.acceptanceRate, query.minAcceptance));
    }

    if (query.maxAcceptance !== undefined) {
      conditions.push(lte(collegesTable.acceptanceRate, query.maxAcceptance));
    }

    if (query.minRanking !== undefined) {
      conditions.push(gte(collegesTable.ranking, query.minRanking));
    }

    if (query.maxRanking !== undefined) {
      conditions.push(lte(collegesTable.ranking, query.maxRanking));
    }

    const colleges =
      conditions.length > 0
        ? await db
            .select()
            .from(collegesTable)
            .where(and(...conditions))
            .orderBy(collegesTable.ranking)
        : await db.select().from(collegesTable).orderBy(collegesTable.ranking);

    res.json(colleges);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid query parameters" });
  }
});

router.get("/colleges/featured", async (req, res) => {
  try {
    const colleges = await db
      .select()
      .from(collegesTable)
      .where(eq(collegesTable.featured, true))
      .orderBy(collegesTable.ranking);
    res.json(colleges);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch featured colleges" });
  }
});

router.get("/colleges/stats", async (req, res) => {
  try {
    const colleges = await db.select().from(collegesTable);
    const totalColleges = colleges.length;
    const states = new Set(colleges.map((c) => c.state)).size;
    const avgAcceptanceRate =
      colleges.reduce((sum, c) => sum + c.acceptanceRate, 0) / totalColleges;
    const totalStudents = colleges.reduce((sum, c) => sum + c.enrollment, 0);

    res.json({ totalColleges, states, avgAcceptanceRate: Math.round(avgAcceptanceRate * 10) / 10, totalStudents });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

router.get("/colleges/:id", async (req, res) => {
  try {
    const { id } = GetCollegeParams.parse({ id: Number(req.params.id) });
    const [college] = await db
      .select()
      .from(collegesTable)
      .where(eq(collegesTable.id, id))
      .limit(1);

    if (!college) {
      res.status(404).json({ error: "College not found" });
      return;
    }

    res.json(college);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

router.post("/colleges/compare", async (req, res) => {
  try {
    const { ids } = CompareCollegesBody.parse(req.body);
    const colleges = await db
      .select()
      .from(collegesTable)
      .where(inArray(collegesTable.id, ids))
      .orderBy(collegesTable.ranking);

    res.json(colleges);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid request" });
  }
});

export default router;
