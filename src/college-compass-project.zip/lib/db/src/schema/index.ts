export * from "./colleges";
